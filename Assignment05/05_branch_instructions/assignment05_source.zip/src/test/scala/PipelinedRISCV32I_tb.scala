package PipelinedRV32I_Tester

import chisel3._
import chiseltest._
import PipelinedRV32I._
import org.scalatest.flatspec.AnyFlatSpec

// -----------------------------------------
// Test cases for Branch and Jump instructions
// -----------------------------------------

//Start code

class PipelinedRISCV32ITest extends AnyFlatSpec with ChiselScalatestTester {

  "RV32I_BranchJumpTester" should "work" in {
    test(new PipelinedRV32I("src/test/programs/BinaryFile_pipelined")).withAnnotations(Seq(WriteVcdAnnotation)) { dut =>

      dut.clock.setTimeout(0)

      //We wait for the pipeline to fill up and process the program
      dut.clock.step(5)


      //SETUP — Check base values load correctly
      dut.io.result.expect(0.U)        // ADDI x0, x0, 0
      dut.clock.step(1)

      dut.io.result.expect(4.U)        // ADDI x1, x0, 4
      dut.clock.step(1)

      dut.io.result.expect(5.U)        // ADDI x2, x0, 5
      dut.clock.step(1)


      //CASE 1 — BEQ NOT taken (4 != 5, pipeline keeps going)
      //Advance and confirm the next instruction after the branch executes normally
      dut.clock.step(1)
      dut.io.result.expect(99.U)       // ADDI x3, x0, 99
      dut.clock.step(1)

      dut.io.result.expect(100.U)      // ADDI x4, x0, 100
      dut.clock.step(1)


      //CASE 2 — BNE taken (4 != 5, flush 2 instructions)
      //After the branch fires, the pipeline flushes and continues at the target
      dut.clock.step(4)  //advance past the branch and flushed slots


      //CASE 3 — JAL (always taken, flush 1 instruction)
      //After JAL, the pipeline reaches ADDI x9, x0, 101
      dut.clock.step(3)
      dut.io.result.expect(101.U)      // ADDI x9, x0, 101 [JAL target]

      //If we reach this expect, all branches and jumps worked correctly
    }
  }
}